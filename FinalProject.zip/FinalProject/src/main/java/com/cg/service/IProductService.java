package com.cg.service;

import java.util.List;

import com.cg.bean.Cart;
import com.cg.bean.Discount;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;

import com.cg.exception.InvalidInputException;
import com.cg.exception.ProductUnavailableException;
import com.cg.model.Excep;

public interface IProductService {
	
	
	
	public Product getProduct(int productId);

	
	public Excep addProductToWishlist(int userId,int productId) throws InvalidInputException;

	public boolean removeProductFromWishlist(int userId,int productId) throws InvalidInputException;

	public List<Product> getWishlist(int userId) throws InvalidInputException;


	Excep addProductToNewCart(int userId,int productId) throws ProductUnavailableException;
	
	List<Product> getAllProductsFromCart(int userId) throws InvalidInputException;
	
	public boolean removeProductFromCart(int userId,int productId)  throws InvalidInputException;
	
public Double checkDiscountOnProductById(Integer productId);


boolean removeAllFromCart(int userId) throws InvalidInputException;
	
	//public Integer applyDiscountOnProduct(Integer productId);
	
	
	
	
}
