package com.cg.bean;

public class SortingFormat {

	private String category;
	
	public SortingFormat() {
		
	}
	public SortingFormat(String category) {
		super();
		this.category = category;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}