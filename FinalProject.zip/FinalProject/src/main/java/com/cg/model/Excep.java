package com.cg.model;

public class Excep {
	 private String status;



	 public String getStatus() {

	 return status;

	 }



	 public Excep() {

	 super();

	 // TODO Auto-generated constructor stub

	 }



	 public Excep(String status) {

	 super();

	 this.status = status;

	 }



	 public void setStatus(String string) {

	 this.status = string;

	 }



	}
			


