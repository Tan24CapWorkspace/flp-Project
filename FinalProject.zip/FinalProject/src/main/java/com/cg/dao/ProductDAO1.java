package com.cg.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bean.Merchant;
import com.cg.bean.Product;

@Repository
public interface ProductDAO1 {
	public List<Product> product(int orderid);

	public List<Merchant> merchantid(int orderid);

	public Product getProduct(int productid);
}
