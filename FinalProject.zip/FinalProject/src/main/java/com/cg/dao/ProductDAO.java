package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Merchant;
import com.cg.bean.Product;

/**
 * @author Tanmay Pathak
 * */
public interface ProductDAO extends JpaRepository<Product, Integer>{
	
	@Query("select p from Product p where category = ?1 and subcategory = ?2")
	public List<Product> getProductsFiltered(String category, String subcategory);
	
	// For getting products in a given range of price
	@Query("from Product  WHERE  category=:category AND price>=:min AND  price<:max")
	public List<Product> getProductsInRange(@Param("category")String category,@Param("min")int min,@Param("max")int max);

	// Sorting by products price in ascending order
	@Query("from Product WHERE  category=:category order by price")
	public List<Product> findByProductCategoryOrderByProductPrice(@Param("category")String category);

	// Sorting by products price in descending order
	@Query("from Product WHERE  category=:category order by price desc")
	public List<Product> findByProductCategoryOrderByProductPriceDesc(@Param("category")String category);

/*	// For getting the most viewed product
	@Query(" from Product WHERE category=:category order by views desc")
	public List<Product> findByproductCategoryOrderByProductViewDesc(@Param("category")String category);
*/
	// For getting the best-seller product
	@Query("from Product WHERE category=:category order by soldQuantities desc")
	public List<Product> findByproductCategoryOrderByProductsSoldDesc(@Param("category")String category);
	
	
	@Query("select p from Product p where p.merchant=?1")
	public Product findbymerchant(Merchant merchant);
	
	@Query("Select p from Product p where p.productID=?1")
	public Product getProduct(int productID);
	
	@Query("select p.price from Product p where p.productID=?1")
	public Integer getProductPrice(int productId);
	
	@Query("select p from Product p")
	List<Product> findAllProduct();
	@Query("select p from Product p where UPPER(p.productName) LIKE UPPER(?1)")
	List<Product> findByProductName(String productName);
	@Query("select p from Product p where UPPER(p.company) LIKE UPPER(?1)")
	List<Product> findByCompany(String company);
	@Query("select p from Product p where  UPPER(p.category) LIKE UPPER(?1)")
	List<Product> findByCategory(String category);
	@Query("select p from Product p where UPPER(p.subcategory) LIKE UPPER(?1)")
	List<Product> findBySubCategory(String subcategory);
	
	
	// only admin can search through productId,user can't
	@Query("select p from Product p where p.productID=?1")
	List<Product> findByProductId(Integer productId);
	
	@Query("select p from Product p where p.merchant=?1")
	List<Product> findAllProductWithMerchantId(Merchant merchantObject);
	
	@Query("select p from Product p where p.merchant=?2 AND p.productID=?1")
	List<Product> findByProductIdWithMerchantId(int productId,Merchant merchantObject);
	
	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.productName) LIKE UPPER(?1)")
	List<Product> findByProductNameWithMerchantId(String productName,Merchant merchantObject);
	
	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.company) LIKE UPPER(?1)")
	List<Product> findByCompanyWithMerchantId(String Company,Merchant merchantObject);
	
	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.category) LIKE UPPER(?1)")
	List<Product> findByCategoryWithMerchantId(String Category,Merchant merchantObject);

    @Query("select p from Product p where p.merchant=?2 AND UPPER(p.subcategory) LIKE UPPER(?1)")
    List<Product> findBySubCategoryWithMerchantId(String subcategory,Merchant merchantObject);
    
    @Query("select p from Product p where p.merchant=?1")
	public List<Product> getAllProductsForMerchant(Merchant merchantObject);
    
    @Query("select p from Product p where p.merchant=?1")
	public Product findbyMerchant(Merchant merchant);
    
    @Modifying
	@Transactional
	@Query("update Product p set p.quantity =p.quantity-?2, p.soldQuantities = p.soldQuantities+?2 where p.productID=?1")
	public void updateProducts(int pid, int cart_quantity);
	
}
