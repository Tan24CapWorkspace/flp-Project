import { Injectable } from "@angular/core";

import { Observable } from "rxjs";
import { Product } from "../models/product";
import { HttpClient } from "@angular/common/http";
import { Sorting } from "../models/sorting";

@Injectable({
    providedIn: 'root'
})

export class ProductService{
    
    url: string = "http://localhost:5000";

    constructor(private http: HttpClient){

    }

    getProducts(): Observable<Product[]>{
        return this.http.get<Product[]>(this.url+"/getproducts");
    }

    

    sortAsc(format:Sorting){
        return this.http.post<Product[]>(this.url+"/sortproductsasc",format)
    }

    sortDesc(format:Sorting){
        return this.http.post<Product[]>(this.url+"/sortproductsdesc",format)
    }

    sortBestSeller(format:Sorting){
        return this.http.post<Product[]>(this.url+"/bestseller",format)
    }
}