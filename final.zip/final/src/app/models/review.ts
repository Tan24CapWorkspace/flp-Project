export class Review{

    reviewId:number;
	userId:string;
	productId:string;
	reviewFeedback:string
    stars:number;
    


    constructor(userId:string,productId:string,reviewFeedback:string,stars:number){
        this.userId=userId;
        this.productId=productId;
        this.reviewFeedback=reviewFeedback;
        this.stars=stars;
    }
}